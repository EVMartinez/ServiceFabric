﻿$ServerCertificateName = "CN=ServiceFabricServerCert"
$ClientCertificateName = "CN=ServiceFabricClientCert"

function IsSecurityX509([string]$ClusterConfigFilePath)
{
    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $properties = $jsonConfig.properties
    if ($properties -ne $Null)
    {
        $security = $properties.security
        if ($security -ne $Null )
        {
            $clusterCredentialType = $security.ClusterCredentialType
            return ($clusterCredentialType -ne $Null -And $clusterCredentialType -eq "X509")
        }
    }
    return $False
}

function IsLocalMachine([string] $MachineName)
{
    return ($MachineName -eq $env:ComputerName) -Or ($MachineName -eq "localhost")
}

function GetHostName([string] $iPAddress)
{
    $hostName = $iPAddress
    if ([bool]($iPAddress -as [ipaddress]))
    {
        $hostName = [System.Net.Dns]::GetHostByAddress($iPAddress).HostName
    }

    return $hostName
}

function IsThisMachineServer([string] $ClusterConfigFilePath)
{
    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $nodes = $jsonConfig.nodes

    Foreach ($node in $nodes)
    {
        $hostName = GetHostName -iPAddress $node.iPAddress

        if (IsLocalMachine -MachineName $hostName)
        {
            return $True;
        }
    }

    return $False
}

function InstallCertToLocal([string] $CertSetupScript)
{
    invoke-expression "& '$CertSetupScript' -Install -CertSubjectName '$ServerCertificateName'"
    invoke-expression "& '$CertSetupScript' -Install -CertSubjectName '$ClientCertificateName'"

    $cerLoc = "cert:\LocalMachine\My"
    $cert =  Get-ChildItem -Path $cerLoc | where { $_.Subject -like "*$ServerCertificateName*" }
    $serverthumbprint = $cert.Thumbprint

    $cert =  Get-ChildItem -Path $cerLoc | where { $_.Subject -like "*$ClientCertificateName*" }
    $clientthumbprint = $cert.Thumbprint
    
    return $serverthumbprint,$clientthumbprint
}

function IsOneBox([string] $ClusterConfigFilePath)
{
    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $nodes = $jsonConfig.nodes

    $machineNames = $nodes.iPAddress | select -uniq
    return ($machineNames.Count -eq 1)
}

function ExportCertificateToLocal([string]$PackageRoot, [string]$CertSetupScript, [string]$ServerThumbprint, [string]$ClientThumbprint, [string]$ClusterConfigFilePath)
{
    $serverCertificate = ExportCertificate -PackageRoot $packageRoot -Thumbprint $serverThumbprint -Name "server"
    $clientCertificate = ExportCertificate -PackageRoot $packageRoot -Thumbprint $clientThumbprint -Name "client"

    Write-Host "Server certificate is exported to $($serverCertificate[0]) with the password $($serverCertificate[1])"
    Write-Host "Client certificate is exported to $($clientCertificate[0]) with the password $($clientCertificate[1])"

    # If the current machine is server, then remove the client cert. If the current machine is client, then remove server cert.
    if (IsThisMachineServer -ClusterConfigFilePath $ClusterConfigFilePath)
    {
        if (-Not (IsOneBox -ClusterConfigFilePath $ClusterConfigFilePath))
        {
            Write-Host "Remove client certificate on localhost."
            invoke-expression "& '$CertSetupScript' -Clean -CertSubjectName '$ClientCertificateName'"
        }
    }
    else 
    {
        Write-Host "Remove server certificate on localhost."
        invoke-expression "& '$CertSetupScript' -Clean -CertSubjectName '$ServerCertificateName'"
    }

    return $serverCertificate
}

function ExportCertificate([string]$PackageRoot, [string]$Thumbprint, [string] $Name)
{
    $OutputCertificateFolder = Join-Path $PackageRoot "Certificates"
    if (-Not(Test-Path $OutputCertificateFolder))
    {
        New-Item -ItemType Directory -Force -Path $OutputCertificateFolder > $null
    }

    $PfxFilePath = "$OutputCertificateFolder\$Name.pfx"
    $randomnum = Get-Random
    $pswd = ConvertTo-SecureString -String "$randomnum" -Force -AsPlainText
    
    Get-ChildItem -Path "cert:\localMachine\my\$Thumbprint" | Export-PfxCertificate -FilePath $PfxFilePath -Password $pswd > $null

    return $PfxFilePath,$randomnum
}

function ModifyJsonThumbprint([string]$ClusterConfigFilePath, [string]$ServerThumbprint, [string]$ClientThumbprint, [string]$OutputPath)
{
    Write-Host "Modify thumbprint in $ClusterConfigFilePath"

    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $securityCertInfo = New-Object -TypeName PSObject

    $certificate= New-Object –TypeName PSObject
    $certificate | Add-Member -Name "Thumbprint" -value "$ServerThumbprint" -MemberType NoteProperty
    $certificate | Add-Member -Name "X509StoreName" -value "My" -MemberType NoteProperty

    $clientcertificate = New-Object -TypeName PSObject
    $clientcertificate | Add-Member -Name "CertificateThumbprint" -value "$ClientThumbprint" -MemberType NoteProperty
    $clientcertificate | Add-Member -Name "IsAdmin" -value $true -MemberType NoteProperty
    $clientcertificateArray = @()
    $clientcertificateArray += $clientcertificate

    $securityCertInfo | Add-Member -Name "ClusterCertificate" -value $certificate -MemberType NoteProperty
    $securityCertInfo | Add-Member -Name "ServerCertificate" -value $certificate -MemberType NoteProperty
    $securityCertInfo | Add-Member -Name "ClientCertificateThumbprints" -value $clientcertificateArray -MemberType NoteProperty

    if (IsReverseProxyEndPointConfigured -ClusterConfigFilePath $ClusterConfigFilePath)
    {
        $securityCertInfo | Add-Member -Name "ReverseProxyCertificate" -value $certificate -MemberType NoteProperty
    }

    $jsonConfig.properties.security.CertificateInformation = $securityCertInfo
    $jsonObject = ConvertTo-Json $jsonConfig -Depth 10
    $jsonObject > $OutputPath
}

function IsReverseProxyEndPointConfigured([string]$ClusterConfigFilePath)
{
    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $nodes = $jsonConfig.nodes
    $properties = $jsonConfig.properties
    $nodetypes = $properties.nodetypes

    foreach($node in $nodes)
    {
        $nodetypeRef = $node.nodetypeRef
        foreach($nodetype in $nodetypes)
        {
            if ($nodetype.Name -eq $nodetypeRef)
            {
                if ($nodetype.reverseProxyEndpointPort -ne $Null)
                {
                    return $True;
                }
            }
        }
    }

    return $False
}

function AddToTrustedHosts([string]$MachineName)
{
    Write-Host "Adding $MachineName to TrustedHosts"
    Set-Item WSMan:\localhost\Client\TrustedHosts -Value "$MachineName" -Concatenate -Force
}

function InstallCertToRemote([string]$ClusterConfigFilePath, [string]$CertificatePath, [string]$Password)
{
    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $nodes = $jsonConfig.nodes
    $pswd = ConvertTo-SecureString -String $Password -Force -AsPlainText
    $certBytes = [System.IO.File]::ReadAllBytes($CertificatePath)

    $iPAddressList = $nodes.iPAddress | select -uniq

    Foreach ($iPAddress in $iPAddressList)
    {
        $machineName = GetHostName -iPAddress $iPAddress

        if (IsLocalMachine -MachineName $machineName)
        {
            Write-Host "Skipping certificate installation in $machineName."
            continue
        }

        AddToTrustedHosts -MachineName $machineName

        Write-Host "Connectting to $machineName"

        for($retry = 0; $retry -le 2; $retry ++)
        {
            Write-Host "Installing server certificate in $machineName for iteration $retry"
            Invoke-Command -ComputerName $machineName -ScriptBlock {
                param($pswd, $certBytes)
                Get-ChildItem -Path Cert:\LocalMachine\My | ? { $_.Subject -like "*$ServerCertificateName*" } | Remove-Item -Force
                Get-ChildItem -Path Cert:\LocalMachine\root | ? { $_.Subject -like "*$ServerCertificateName*" } | Remove-Item -Force
                Get-ChildItem -Path Cert:\CurrentUser\My | ? { $_.Subject -like "*$ServerCertificateName*" } | Remove-Item -Force

                $certPath = [System.IO.Path]::GetTempFileName()
                [system.IO.file]::WriteAllBytes($certPath, $certBytes);

                Import-PfxCertificate -Exportable -CertStoreLocation Cert:\LocalMachine\My -FilePath $certPath -Password $pswd > $null   
                Import-PfxCertificate -Exportable -CertStoreLocation Cert:\LocalMachine\root -FilePath $certPath -Password $pswd > $null  
                Import-PfxCertificate -Exportable -CertStoreLocation Cert:\CurrentUser\My -FilePath $certPath -Password $pswd > $null  

            } -ArgumentList $pswd,$certBytes

            if ($?)
            {
                Write-Host "Installed server certificate in $machineName"
                break
            }

            if ($retry -eq 2)
            {
                Write-Host "Installing server certificate in $machineName failed after 3 attemps"
            }
            else 
            {
                Write-Host "Unable to intall server certificate in $machineName, retry after 30 seconds..."
                Start-Sleep -Seconds 30
            } 
        }        
    }  
}
# SIG # Begin signature block
# MIIdkAYJKoZIhvcNAQcCoIIdgTCCHX0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUA9N5lOI398Qw7sSN8QBflzhp
# H/mgghhUMIIEwzCCA6ugAwIBAgITMwAAALWsfW2HayYRRwAAAAAAtTANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODQ0
# WhcNMTgwOTA3MTc1ODQ0WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkI4RUMtMzBBNC03MTQ0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApXwz2j7k2rDl
# 2QO9eyz1qUm3FyqD7dksbP5M3NCOq/j95vpOeHG2w0S1SyNmN8VEqjiHSeopO5b+
# VbOIbpqqG9PyfyDc0WdzIilufZOuwyZI15hI3uRgZ78E/cbljXUW5Me75jGGEOlr
# Gek41eOyGRUxkejFapqkiHCLxHSMHEpPdT95ylPhuLz7Bq01fsQSbclDoQye3EzO
# YFlqcFMYb3s61siEbpvKgf0qcQjPzAh3vsySXqzeeLc3Kzss74E9HDduQGO1ZZTZ
# FadL4bzwlgVhux25DZr0zqybZIBiy8/J9oyKCi2OuWLqxf+YgSWp0YMY9ktvKwGr
# VW7W8/UJVwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFIMd6iA083bzGHST2k2O6R6l
# XnyFMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAAez+vxJWgDsgMtouMLKUcbt+zRbXcxWm2HmTU7rhIVVyh2E
# IFS5ebVknSGsKoR1/xlEmnMo3fHtvWaDRo/2qXIg1jMnOQp1d4wqFh9hKfnDeCQA
# 9tCnM8C/mYu3axXxKmyxJXDOm2MqcoZ9CBlmk96o/hzV9QWo5c+Y94j7qEYpGRPG
# 6Adqoc/HNxnce3Ik0ZlpbD8TbmbIjDORxQ3Jjbn3AGXBQ+smsInwWFzut2EwpGPC
# 2xWhLjXLdzJReIM1geh3oM/wti4zZ4w7hr4CvedMnU29OkcnoyMEUAQnZfB7PsXm
# adKxnklsJCsr1UOu7g/nwX5/mcw7R9G3RSvrI0EwggYAMIID6KADAgECAhMzAAAA
# ww6bp9iy3PcsAAAAAADDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTEwHhcNMTcwODExMjAyMDI0WhcNMTgwODExMjAyMDI0WjB0
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQC7V9c40bEGf0ktqW2zY596urY6IVu0mK6N1KSBoMV1xSzvgkAqt4FTd/Nj
# AQq8zjeEA0BDV4JLzu0ftv2AbcnCkV0Fx9xWWQDhDOtX3v3xuJAnv3VK/HWycli2
# xUibM2IF0ZWUpb85Iq2NEk1GYtoyGc6qIlxWSLFvRclndmJdMIijLyjFH1Aq2Ybb
# GhElgcL09Wcu53kd9eIcdfROzMf8578LgEcp/8/NabEMC2DrZ+aEG5tN/W1HOsfZ
# wWFh8pUSoQ0HrmMh2PSZHP94VYHupXnoIIJfCtq1UxlUAVcNh5GNwnzxVIaA4WLb
# gnM+Jl7wQBLSOdUmAw2FiDFfCguLAgMBAAGjggF/MIIBezAfBgNVHSUEGDAWBgor
# BgEEAYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUpxNdHyGJVegD7p4XNuryVIg1
# Ga8wUQYDVR0RBEowSKRGMEQxDDAKBgNVBAsTA0FPQzE0MDIGA1UEBRMrMjMwMDEy
# K2M4MDRiNWVhLTQ5YjQtNDIzOC04MzYyLWQ4NTFmYTIyNTRmYzAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AE2XTzR+8XCTnOPVGkucEX5rJsSlJPTfRNQkurNqCImZmssx53Cb/xQdsAc5f+Qw
# OxMi3g7IlWe7bn74fJWkkII3k6aD00kCwaytWe+Rt6dmAA6iTCXU3OddBwLKKDRl
# OzmDrZUqjsqg6Ag6HP4+e0BJlE2OVCUK5bHHCu5xN8abXjb1p0JE+7yHsA3ANdkm
# h1//Z+8odPeKMAQRimfMSzVgaiHnw40Hg16bq51xHykmCRHU9YLT0jYHKa7okm2Q
# fwDJqFvu0ARl+6EOV1PM8piJ858Vk8gGxGNSYQJPV0gc9ft1Esq1+fTCaV+7oZ0N
# aYMn64M+HWsxw+4O8cSEQ4fuMZwGADJ8tyCKuQgj6lawGNSyvRXsN+1k02sVAiPG
# ijOHOtGbtsCWWSygAVOEAV/ye8F6sOzU2FL2X3WBRFkWOCdTu1DzXnHf99dR3DHV
# GmM1Kpd+n2Y3X89VM++yyrwsI6pEHu77Z0i06ELDD4pRWKJGAmEmWhm/XJTpqEBw
# 51swTHyA1FBnoqXuDus9tfHleR7h9VgZb7uJbXjiIFgl/+RIs+av8bJABBdGUNQM
# bJEUfe7K4vYm3hs7BGdRLg+kF/dC/z+RiTH4p7yz5TpS3Cozf0pkkWXYZRG222q3
# tGxS/L+LcRbELM5zmqDpXQjBRUWlKYbsATFtXnTGVjELMIIGBzCCA++gAwIBAgIK
# YRZoNAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29t
# MRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEw
# NDAzMTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSEwHwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4k
# D+7Rp9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMk
# h53y9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDl
# KEYuJ6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gA
# SkdmEScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1U
# n68eeEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIB
# pzAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWz
# DzALBgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAU
# DqyCYEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20x
# GTAXBgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBS
# b290IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNV
# HR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9w
# cm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQG
# CCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01p
# Y3Jvc29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQS
# ooxtYrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBT
# Fd1Pq5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2Oawpylbih
# OZxnLcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfr
# Tot/xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWG
# zFFW6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H21
# 46SodDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4i
# IdBD6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2
# sWo9iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1
# sMpjtHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/J
# mu5J4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0wggd6
# MIIFYqADAgECAgphDpDSAAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDla
# Fw0yNjA3MDgyMTA5MDlaMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS6
# 8rZYIZ9CGypr6VpQqrgGOBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15
# ZId+lGAkbK+eSZzpaF7S35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+er
# CFDPs0S3XdjELgN1q2jzy23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVc
# eaVJKecNvqATd76UPe/74ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGM
# XeiJT4Qa8qEvWeSQOy2uM1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/
# U7qcD60ZI4TL9LoDho33X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwj
# p6lm7GEfauEoSZ1fiOIlXdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwC
# gl/bwBWzvRvUVUvnOaEP6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1J
# MKerjt/sW5+v/N2wZuLBl4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3co
# KPHtbcMojyyPQDdPweGFRInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfe
# nk70lrC8RqBsmNLg1oiMCwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAw
# HQYDVR0OBBYEFEhuZOVQBdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoA
# UwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQY
# MBaAFHItOgIxkEO5FAVO4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6
# Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1
# dDIwMTFfMjAxMV8wM18yMi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAC
# hkJodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1
# dDIwMTFfMjAxMV8wM18yMi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4D
# MIGDMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2RvY3MvcHJpbWFyeWNwcy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBs
# AF8AcABvAGwAaQBjAHkAXwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcN
# AQELBQADggIBAGfyhqWY4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjD
# ctFtg/6+P+gKyju/R6mj82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw
# /WvjPgcuKZvmPRul1LUdd5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkF
# DJvtaPpoLpWgKj8qa1hJYx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3z
# Dq+ZKJeYTQ49C/IIidYfwzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEn
# Gn+x9Cf43iw6IGmYslmJaG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1F
# p3blQCplo8NdUmKGwx1jNpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0Qax
# dR8UvmFhtfDcxhsEvt9Bxw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AAp
# xbGbpT9Fdx41xtKiop96eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//W
# syNodeav+vyL6wuA6mk7r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqx
# P/uozKRdwaGIm1dxVk5IRcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIEpjCC
# BKICAQEwgZUwfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEo
# MCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAMMO
# m6fYstz3LAAAAAAAwzAJBgUrDgMCGgUAoIG6MBkGCSqGSIb3DQEJAzEMBgorBgEE
# AYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJ
# BDEWBBQeYM63BNvftBOc0NEAgjcjv3qzrzBaBgorBgEEAYI3AgEMMUwwSqAkgCIA
# TQBpAGMAcgBvAHMAbwBmAHQAIABXAGkAbgBkAG8AdwBzoSKAIGh0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS93aW5kb3dzMA0GCSqGSIb3DQEBAQUABIIBAEVM8A7qEBXV
# mabp3y1FXzt/Lf3yVP9wCGbQCBJlrlqQVTaus/wxMx5UIaZNKkeTGrLlMcabuviA
# N/UW2ONT6JenNzKOedNjkLAlrUXl6x5juseNP+yUfH/jxDjg/e13ht5gzeatydIo
# Ot12SofRCLGd5Bn58wzEEwF9jgcHFRPxla4LVLfMedNS94W6UwOuekjruhBj6B4j
# jz9txzvxY/p0bkhTrbCDEN+agCoBEDnJyyHJlKeUFNUHXuFsM0fTYbAy9hvBWGCU
# i3Lwo3BtxA22cXvsp1tS/rn0LGBnEsNkywnfALiumJCScvoV0NAK0lnAd74vPxrN
# AB9BdaeJhA+hggIoMIICJAYJKoZIhvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBAhMzAAAAtax9bYdrJhFHAAAAAAC1MAkGBSsOAwIa
# BQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0x
# ODA3MDMyMzA3NDFaMCMGCSqGSIb3DQEJBDEWBBRoms1NzMn1B4VfekMVj6TmS/vK
# wzANBgkqhkiG9w0BAQUFAASCAQAj7W2Ng3iTO01kQvdIAR+sP6iXpiOAmlbaHst0
# ipJfmONFRslDINH7DCkn3ppFUsY2QmR2YaW7xIGXmwUpJm1quOfcq8dXWyI6fJ/M
# MFvZSIBLycbRFikKAQVf2Oa3Z9FKOfLLbnejeijybCbvJycvoaHnukQqYh4/QiJ1
# xZjYk3SP/gcxmzm8QB6K4fQn51qkkBxDUV3+5IbcfjJXMnwat+uG/9j64IZop0Ku
# cAbg20fIYTeZN7tCSpRl82ds2tkl1Ofl5HN4Tmfm9UMguRRf6yMkczHmf7+DYG7H
# ZVwghx9O2cDJDu23fKJ8DL2eP6vZs5nviGovQgSEo8zuqNr4
# SIG # End signature block
