# ------------------------------------------------------------
# Copyright (c) Microsoft Corporation.  All rights reserved.
# Licensed under the MIT License (MIT). See License.txt in the repo root for license information.
# ------------------------------------------------------------

[CmdletBinding(DefaultParametersetName="Unsecure")] 
param (
    [Parameter(ParameterSetName="Unsecure", Mandatory=$true)]
    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [string] $NodeName,

    [Parameter(ParameterSetName="Unsecure", Mandatory=$true)]
    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [string] $NodeType,

    [Parameter(ParameterSetName="Unsecure", Mandatory=$true)]
    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [string] $NodeIpAddressOrFQDN,

    [Parameter(ParameterSetName="Unsecure", Mandatory=$true)]
    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [string] $ExistingClientConnectionEndpoint,

    [Parameter(ParameterSetName="Unsecure", Mandatory=$true)]
    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [string] $UpgradeDomain,

    [Parameter(ParameterSetName="Unsecure", Mandatory=$true)]
    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [string] $FaultDomain,

    [Parameter(ParameterSetName="Unsecure", Mandatory=$false)]
    [Parameter(ParameterSetName="Certificate", Mandatory=$false)]
    [switch] $AcceptEULA,

    [Parameter(ParameterSetName="Unsecure", Mandatory=$false)]
    [Parameter(ParameterSetName="Certificate", Mandatory=$false)]
    [string] $FabricRuntimePackagePath,
    
    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [switch] $X509Credential,

    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [string] $ServerCertThumbprint,

    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [string] $StoreLocation,

    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [string] $StoreName,

    [Parameter(ParameterSetName="Certificate", Mandatory=$true)]
    [string] $FindValueThumbprint
)

$Identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$Principal = New-Object System.Security.Principal.WindowsPrincipal($Identity)
$IsAdmin = $Principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)

if(!$IsAdmin)
{
    Write-host "Please run the script with administrative privileges." -ForegroundColor "Red"
    exit 1
}

if(!$AcceptEULA.IsPresent)
{
    $EulaAccepted = Read-Host 'Do you accept the license terms for using Microsoft Azure Service Fabric located in the root of your package download? If you do not accept the license terms you may not use the software.
[Y] Yes  [N] No  [?] Help (default is "N")'
    if($EulaAccepted -ne "y" -and $EulaAccepted -ne "Y")
    {
        Write-host "You need to accept the license terms for using Microsoft Azure Service Fabric located in the root of your package download before you can use the software." -ForegroundColor "Red"
        exit 1
    }
}

$ThisScriptPath = $(Split-Path -parent $MyInvocation.MyCommand.Definition)
$DeployerBinPath = Join-Path $ThisScriptPath -ChildPath "DeploymentComponents"
if(!(Test-Path $DeployerBinPath))
{
    $DCAutoExtractorPath = Join-Path $ThisScriptPath "DeploymentComponentsAutoextractor.exe"
    if(!(Test-Path $DCAutoExtractorPath)) 
    {
        Write-Host "Standalone package DeploymentComponents and DeploymentComponentsAutoextractor.exe are not present local to the script location."
        exit 1
    }

    #Extract DeploymentComponents
    $DCExtractArguments = "/E /Y /L `"$ThisScriptPath`""
    $DCExtractOutput = cmd.exe /c "$DCAutoExtractorPath $DCExtractArguments && exit 0 || exit 1"
    if($LASTEXITCODE -eq 1)
    {
        Write-Host "Extracting DeploymentComponents Cab ran into an issue."
        Write-Host $DCExtractOutput
        exit 1
    }
    else
    {
        Write-Host "DeploymentComponents extracted."
    }
}

$SystemFabricModulePath = Join-Path $DeployerBinPath -ChildPath "System.Fabric.dll"
if(!(Test-Path $SystemFabricModulePath)) 
{
    Write-Host "Run the script local to the Standalone package directory."
    exit 1
}

$MicrosoftServiceFabricCabFileAbsolutePath = $null
if($FabricRuntimePackagePath)
{
    $MicrosoftServiceFabricCabFileAbsolutePath = Resolve-Path $FabricRuntimePackagePath
    if(!(Test-Path $MicrosoftServiceFabricCabFileAbsolutePath)) 
    {
        Write-Host "Microsoft Service Fabric Runtime package not found in the specified directory : $FabricRuntimePackagePath"
        exit 1
    }
}
else
{
    $RuntimeBinPath = Join-Path $ThisScriptPath -ChildPath "DeploymentRuntimePackages"
    if(!(Test-Path $RuntimeBinPath)) 
    {
        Write-Host "No directory exists for Runtime packages. Creating a new directory."
        md $RuntimeBinPath | Out-Null
        Write-Host "Done creating $RuntimeBinPath"
    }
}

$ServiceFabricPowershellModulePath = Join-Path $DeployerBinPath -ChildPath "ServiceFabric.psd1"

# Invoke in separate AppDomain
if($X509Credential)
{
    $argList = @($DeployerBinPath, $ExistingClientConnectionEndpoint, $ServiceFabricPowershellModulePath, $NodeName, $NodeType, $NodeIpAddressOrFQDN, $UpgradeDomain, $FaultDomain, $MicrosoftServiceFabricCabFileAbsolutePath, $true, $ServerCertThumbprint, $StoreLocation, $StoreName, $FindValueThumbprint)
}
else
{
    $argList = @($DeployerBinPath, $ExistingClientConnectionEndpoint, $ServiceFabricPowershellModulePath, $NodeName, $NodeType, $NodeIpAddressOrFQDN, $UpgradeDomain, $FaultDomain, $MicrosoftServiceFabricCabFileAbsolutePath )
}

Powershell -Command {
    param (
        [Parameter(Mandatory=$true)]
        [string] $DeployerBinPath,
        
        [Parameter(Mandatory=$true)]
        [string] $ExistingClientConnectionEndpoint,

        [Parameter(Mandatory=$true)]
        [string] $ServiceFabricPowershellModulePath,

        [Parameter(Mandatory=$true)]
        [string] $NodeName,

        [Parameter(Mandatory=$true)]
        [string] $NodeType,

        [Parameter(Mandatory=$true)]
        [string] $NodeIpAddressOrFQDN,

        [Parameter(Mandatory=$true)]
        [string] $UpgradeDomain,

        [Parameter(Mandatory=$true)]
        [string] $FaultDomain,

        [Parameter(Mandatory=$false)]
        [string] $MicrosoftServiceFabricCabFileAbsolutePath,

        [Parameter(Mandatory=$false)]
        [bool] $X509Credential,

        [Parameter(Mandatory=$false)]
        [string] $ServerCertThumbprint,

        [Parameter(Mandatory=$false)]
        [string] $StoreLocation,

        [Parameter(Mandatory=$false)]
        [string] $StoreName,

        [Parameter(Mandatory=$false)]
        [string] $FindValueThumbprint
    )
    
    #Add FabricCodePath Environment Path
    $env:path = "$($DeployerBinPath);" + $env:path

    #Import Service Fabric Powershell Module
    Import-Module $ServiceFabricPowershellModulePath

    Try
    {
        # Connect to the existing cluster
        if($X509Credential)
        {
            Connect-ServiceFabricCluster -ConnectionEndpoint $ExistingClientConnectionEndpoint -X509Credential -ServerCertThumbprint $ServerCertThumbprint -StoreLocation $StoreLocation -StoreName $StoreName -FindValue $FindValueThumbprint -FindType FindByThumbprint
        }
        else
        {
            Connect-ServiceFabricCluster $ExistingClientConnectionEndpoint
        }
        
        if(!$MicrosoftServiceFabricCabFileAbsolutePath)
        {				
            # Get runtime package details
            $UpgradeStatus = Get-ServiceFabricClusterUpgrade
            if($UpgradeStatus.UpgradeState -ne "RollingForwardCompleted" -And $UpgradeStatus.UpgradeState -ne "RollingBackCompleted")
            {		
                Write-Host "New node cannot be added to the cluster while upgrade is in progress or before cluster has finished bootstrapping. To monitor upgrade state run Get-ServiceFabricClusterUpgrade and wait till UpgradeState switches to either RollingForwardCompleted or RollingBackCompleted." -ForegroundColor Red
                exit 1
            }
            $RuntimeCabFilename = "MicrosoftAzureServiceFabric." + $UpgradeStatus.TargetCodeVersion + ".cab"
            $DeploymentPackageRoot = Split-Path -parent $DeployerBinPath
            $RuntimeBinPath = Join-Path $DeploymentPackageRoot -ChildPath "DeploymentRuntimePackages"
            $MicrosoftServiceFabricCabFilePath = Join-Path $RuntimeBinPath -ChildPath $RuntimeCabFilename
            if(!(Test-Path $MicrosoftServiceFabricCabFilePath)) 
            {
                $RuntimePackageDetails = Get-ServiceFabricRuntimeSupportedVersion
                $RequiredPackage = $RuntimePackageDetails.RuntimePackages | where { $_.Version -eq $UpgradeStatus.TargetCodeVersion }
                if($RequiredPackage -eq $null)
                {
                    Write-Host "The required runtime version is no longer supported. Please upgrade your cluster to the latest version before adding a node." -ForegroundColor Red
                    exit 1
                }
                    $Version = $UpgradeStatus.TargetCodeVersion
                    Write-Host "Runtime package version $Version was not found in DeploymentRuntimePackages folder and needed to be downloaded."
                    (New-Object System.Net.WebClient).DownloadFile($RuntimePackageDetails.GoalRuntimeLocation, $MicrosoftServiceFabricCabFilePath)
                    Write-Host "Runtime package has been successfully downloaded to $MicrosoftServiceFabricCabFilePath."
            }
            $MicrosoftServiceFabricCabFileAbsolutePath = Resolve-Path $MicrosoftServiceFabricCabFilePath
        }
    }
    Catch
    {
        Write-Host "Runtime package cannot be downloaded. Check you internet connectivity. If the cluster is not connected to the internet run Get-ServiceFabricClusterUpgrade and note the TargetCodeVersion. Run Get-ServiceFabricRuntimeSupportedVersion from a machine connected to the internet to get the download links for all supported fabric versions. Download the package corresponding to your TargetCodeVersion. Pass -FabricRuntimePackageOutputDirectory <Path to runtime package> to AddNode.ps1 in addition to other parameters. Exception thrown : $($_.Exception.ToString())" -ForegroundColor Red
        exit 1
    }

    #Add Node to an existing cluster
    Try
    {
        Get-ServiceFabricNode | ft
        Add-ServiceFabricNode -NodeName $NodeName -NodeType $NodeType -IpAddressOrFQDN $NodeIpAddressOrFQDN -UpgradeDomain $UpgradeDomain -FaultDomain $FaultDomain -FabricRuntimePackagePath $MicrosoftServiceFabricCabFileAbsolutePath -Verbose

        Start-Sleep -s 30
        Get-ServiceFabricNode |ft
    }
    Catch
    {
        Write-Host "Add node to existing cluster failed with exception: $($_.Exception.ToString())" -ForegroundColor Red
        exit 1
    }
    
} -args $argList -OutputFormat Text

$env:Path = [System.Environment]::GetEnvironmentVariable("path","Machine")
# SIG # Begin signature block
# MIIdkAYJKoZIhvcNAQcCoIIdgTCCHX0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUgSoGmoelTf4JbnS9KQwxTrVH
# dIegghhUMIIEwzCCA6ugAwIBAgITMwAAALbYAJUMg2JtoQAAAAAAtjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODQ0
# WhcNMTgwOTA3MTc1ODQ0WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OjMxQzUtMzBCQS03QzkxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlitSnGveWTDN
# e1jrQZjYpA9N4OXmCTtz/jy98iVz0ro/f2ELzjwkrzQycPykmlVlOxzzzaSIBmqK
# HiWJXU9m6mU0WS8/O8GV2U8d9PA057wJ/6+3ptVocqSANSNpXip5qKRl5P1Wac0Z
# 5oJ1NOXPnu1J4slB7ssE2ifDwS+0kHkTU3FdKeh8dAoC7GoQU0aFQdPFikvh7YRa
# gwPzzPVs96zCJdIY4gPGqdi8ajX3xrJI4th7QdO98fpj8f1CBJtlELMDiaMwUu0e
# 2VLTFE1sl1cyer4afcTuf+ENNRyiH+LJ5nHRK3/zkTYpjv8G/tfp3swk2ha9tsPP
# ddCge17XYQIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFOjzQTSj/oQgLDnBEUwqsxz4
# 7wKyMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAGotNN2Ff2yTVo4VKnHCmG+PxMuqhs1ke1JE5bQu3bGRgIWX
# riEZvWVqgDUihF4GmcPRHatBE9qtM5ewhDuSIGBf/5rqskW00Q4Kgb7mDtx/sOV7
# wNXJ0HjFgyNRqVDVxVE6uZ8bCTi+TjhfuIBZj85UbdfG/qtPkQkzgmaK83dgLPEH
# T8Je8gd7orVPNkI3lqkQbQ8X4ZISiP+heRsPYtlgeMGvnle5ssGzB2O5Ozt527Fa
# Ztpxi32uN1Qk8hV7xM+Z4ujOGqJFxVQfCGlMU0tXTvaRNoNpKWSp2fjYHyasLXAU
# y7ZhZHq7qWAilzmqCFYZIDPJmjUtm1/hqhqqqxQwggYAMIID6KADAgECAhMzAAAA
# ww6bp9iy3PcsAAAAAADDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTEwHhcNMTcwODExMjAyMDI0WhcNMTgwODExMjAyMDI0WjB0
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQC7V9c40bEGf0ktqW2zY596urY6IVu0mK6N1KSBoMV1xSzvgkAqt4FTd/Nj
# AQq8zjeEA0BDV4JLzu0ftv2AbcnCkV0Fx9xWWQDhDOtX3v3xuJAnv3VK/HWycli2
# xUibM2IF0ZWUpb85Iq2NEk1GYtoyGc6qIlxWSLFvRclndmJdMIijLyjFH1Aq2Ybb
# GhElgcL09Wcu53kd9eIcdfROzMf8578LgEcp/8/NabEMC2DrZ+aEG5tN/W1HOsfZ
# wWFh8pUSoQ0HrmMh2PSZHP94VYHupXnoIIJfCtq1UxlUAVcNh5GNwnzxVIaA4WLb
# gnM+Jl7wQBLSOdUmAw2FiDFfCguLAgMBAAGjggF/MIIBezAfBgNVHSUEGDAWBgor
# BgEEAYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUpxNdHyGJVegD7p4XNuryVIg1
# Ga8wUQYDVR0RBEowSKRGMEQxDDAKBgNVBAsTA0FPQzE0MDIGA1UEBRMrMjMwMDEy
# K2M4MDRiNWVhLTQ5YjQtNDIzOC04MzYyLWQ4NTFmYTIyNTRmYzAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AE2XTzR+8XCTnOPVGkucEX5rJsSlJPTfRNQkurNqCImZmssx53Cb/xQdsAc5f+Qw
# OxMi3g7IlWe7bn74fJWkkII3k6aD00kCwaytWe+Rt6dmAA6iTCXU3OddBwLKKDRl
# OzmDrZUqjsqg6Ag6HP4+e0BJlE2OVCUK5bHHCu5xN8abXjb1p0JE+7yHsA3ANdkm
# h1//Z+8odPeKMAQRimfMSzVgaiHnw40Hg16bq51xHykmCRHU9YLT0jYHKa7okm2Q
# fwDJqFvu0ARl+6EOV1PM8piJ858Vk8gGxGNSYQJPV0gc9ft1Esq1+fTCaV+7oZ0N
# aYMn64M+HWsxw+4O8cSEQ4fuMZwGADJ8tyCKuQgj6lawGNSyvRXsN+1k02sVAiPG
# ijOHOtGbtsCWWSygAVOEAV/ye8F6sOzU2FL2X3WBRFkWOCdTu1DzXnHf99dR3DHV
# GmM1Kpd+n2Y3X89VM++yyrwsI6pEHu77Z0i06ELDD4pRWKJGAmEmWhm/XJTpqEBw
# 51swTHyA1FBnoqXuDus9tfHleR7h9VgZb7uJbXjiIFgl/+RIs+av8bJABBdGUNQM
# bJEUfe7K4vYm3hs7BGdRLg+kF/dC/z+RiTH4p7yz5TpS3Cozf0pkkWXYZRG222q3
# tGxS/L+LcRbELM5zmqDpXQjBRUWlKYbsATFtXnTGVjELMIIGBzCCA++gAwIBAgIK
# YRZoNAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29t
# MRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEw
# NDAzMTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSEwHwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4k
# D+7Rp9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMk
# h53y9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDl
# KEYuJ6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gA
# SkdmEScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1U
# n68eeEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIB
# pzAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWz
# DzALBgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAU
# DqyCYEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20x
# GTAXBgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBS
# b290IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNV
# HR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9w
# cm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQG
# CCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01p
# Y3Jvc29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQS
# ooxtYrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBT
# Fd1Pq5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2Oawpylbih
# OZxnLcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfr
# Tot/xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWG
# zFFW6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H21
# 46SodDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4i
# IdBD6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2
# sWo9iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1
# sMpjtHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/J
# mu5J4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0wggd6
# MIIFYqADAgECAgphDpDSAAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDla
# Fw0yNjA3MDgyMTA5MDlaMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS6
# 8rZYIZ9CGypr6VpQqrgGOBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15
# ZId+lGAkbK+eSZzpaF7S35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+er
# CFDPs0S3XdjELgN1q2jzy23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVc
# eaVJKecNvqATd76UPe/74ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGM
# XeiJT4Qa8qEvWeSQOy2uM1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/
# U7qcD60ZI4TL9LoDho33X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwj
# p6lm7GEfauEoSZ1fiOIlXdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwC
# gl/bwBWzvRvUVUvnOaEP6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1J
# MKerjt/sW5+v/N2wZuLBl4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3co
# KPHtbcMojyyPQDdPweGFRInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfe
# nk70lrC8RqBsmNLg1oiMCwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAw
# HQYDVR0OBBYEFEhuZOVQBdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoA
# UwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQY
# MBaAFHItOgIxkEO5FAVO4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6
# Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1
# dDIwMTFfMjAxMV8wM18yMi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAC
# hkJodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1
# dDIwMTFfMjAxMV8wM18yMi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4D
# MIGDMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2RvY3MvcHJpbWFyeWNwcy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBs
# AF8AcABvAGwAaQBjAHkAXwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcN
# AQELBQADggIBAGfyhqWY4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjD
# ctFtg/6+P+gKyju/R6mj82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw
# /WvjPgcuKZvmPRul1LUdd5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkF
# DJvtaPpoLpWgKj8qa1hJYx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3z
# Dq+ZKJeYTQ49C/IIidYfwzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEn
# Gn+x9Cf43iw6IGmYslmJaG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1F
# p3blQCplo8NdUmKGwx1jNpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0Qax
# dR8UvmFhtfDcxhsEvt9Bxw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AAp
# xbGbpT9Fdx41xtKiop96eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//W
# syNodeav+vyL6wuA6mk7r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqx
# P/uozKRdwaGIm1dxVk5IRcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIEpjCC
# BKICAQEwgZUwfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEo
# MCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAMMO
# m6fYstz3LAAAAAAAwzAJBgUrDgMCGgUAoIG6MBkGCSqGSIb3DQEJAzEMBgorBgEE
# AYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJ
# BDEWBBRClh3dmiqxF67drFtpe3LmiCckgTBaBgorBgEEAYI3AgEMMUwwSqAkgCIA
# TQBpAGMAcgBvAHMAbwBmAHQAIABXAGkAbgBkAG8AdwBzoSKAIGh0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS93aW5kb3dzMA0GCSqGSIb3DQEBAQUABIIBAAMSJ1R6Flxu
# FumtZ3XTLc9Fktt8QrmwW3t/10oqDeAX/y/mn1b/Oa853xxmsB7Pn7Tduj0PQUoD
# Zkd5RRTPMiGn3XUuLTz5ST8+2+LvVpVjomAnSqybyIu9e+wCbhEfMqdIwnAnjwRl
# ztwrCkvd+mJMFa7XkoMeX5OAlAPzkSUIY+leHA8msQyhcbJGZA7eEoH4LgeCmUcH
# CYUiIjf+M2c+x0oJa0UNgsm/+CuOAzVBq14ObdcZQYFaTNiSxFizSJkFe2Y1APIv
# lh1vgTOwdK1YBE8//amSRMBGHhN7ro8zeBjYzFsgXEH43yk0KUaS6dPyyusKv9qE
# rt1X04Bw4u+hggIoMIICJAYJKoZIhvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBAhMzAAAAttgAlQyDYm2hAAAAAAC2MAkGBSsOAwIa
# BQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0x
# ODA3MDMyMzA3MThaMCMGCSqGSIb3DQEJBDEWBBQJFWBYaZeZsWhIb6jRjiTDVGe7
# KDANBgkqhkiG9w0BAQUFAASCAQAl589EKoijhIL54onTWupscvIHw88B3SXSRc/x
# nHStvQc8PT3HXljNSNXzIhiPcOIERWnGTpQ1+RWkSKO1s1U7LaD5C/UUzopCzWLA
# ONL4XNugZxFXaReG42YxItmyvnVJG7Kul+5wkjM3MzzVaCpQH+TWtf71UudiBqxi
# RMSZ+0hi8FwLow+2R0pYBS0sNFbvI7v3Y6HU8KxZAdhOWtmr/tehopEAUcbKFzix
# twwFdVhHXGsv09NtIvSzEDlECEF2yW4zvFpALsk4jHQ30RlLlndie14nfYdyEsIS
# kAOPpXXylCP/VzoHIrKKICRT9A15k4tFvPbAnOBDMcQ+ee11
# SIG # End signature block
